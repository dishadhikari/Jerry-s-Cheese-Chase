import os

print(os.path.exists('t1/t2/t3/Tom/TOM.PSDout.obj'))
