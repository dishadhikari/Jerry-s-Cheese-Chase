from ursina import *

def update():
    if held_keys['left arrow']:
        Jerry.x-=5*time.dt
    if held_keys['right arrow']:
        Jerry.x+=5*time.dt
    if held_keys['up arrow']:
        Jerry.z+=5*time.dt
    if held_keys['down arrow']:
        Jerry.z-=5*time.dt
    if Jerry.intersects(Maze).hit:
        Jerry.position = start_position

app = Ursina()

Maze = Entity(model = 'Assets/Super Jaagub (1).glb',
             scale=100,
             position=(0,0,0),
             rotation=(0,0,0),
             collider='mesh',
             texture='brick')
Jerry = Entity(model = 'cube',
             color = color.magenta,
             texture = 'shore',
             position = (-1.7, 1, -7),
             rotation = (0, 0, 0),
             scale = 0.5,
             collider='box',)
start_position = (-1.7, 1, -7)
Jerry.position = start_position
cheese1 = Entity(model = 'sphere',
               position = (9, 1, 2),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)
cheese2 = Entity(model = 'sphere',
               position = (7, 1, -3),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)
cheese3 = Entity(model = 'sphere',
               position = (8, 1, -8),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)
cheese4 = Entity(model = 'sphere',
               position = (1, 1, -6.3),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)
cheese5 = Entity(model = 'sphere',
               position = (-1.5, 1, 2),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)
cheese6 = Entity(model = 'sphere',
               position = (-7, 1, 0.3),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)
cheese7 = Entity(model = 'sphere',
               position = (-4, 1, 4),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)
cheese8 = Entity(model = 'sphere',
               position = (-8, 1, 6),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)
cheese9 = Entity(model = 'sphere',
               position = (-3, 1, 6),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)
cheese10 = Entity(model = 'sphere',
               position = (-3.7, 1, -1.7),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)
cheese11 = Entity(model = 'sphere',
               position = (-3.5, 1, -7),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)
cheese12 = Entity(model = 'sphere',
               position = (2, 1, 5),
               color = color.gold,
               texture = 'brick',
               scale = 2,)
cheese13 = Entity(model = 'sphere',
               position = (2, 1, -4.5),
               color = color.gold,
               texture = 'brick',
               scale = 0.5,)



EditorCamera()

app.run()